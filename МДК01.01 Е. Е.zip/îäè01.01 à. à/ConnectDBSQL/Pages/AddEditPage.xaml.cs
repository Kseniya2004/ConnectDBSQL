﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ConnectDBSQL.Classes;

namespace ConnectDBSQL.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPage.xaml
    /// </summary>
    public partial class AddEditPage : Page
    {
        //поле которое будет хранить в себе экземпляр пользователя
        private Person _person = new Person();
        public AddEditPage()
        {
            InitializeComponent();
            DataContext = _person;            

        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_person.FirstName))
                error.AppendLine("Укажите имя");
            if(string.IsNullOrWhiteSpace(_person.LastName))
                error.AppendLine("Укажите фамилию");
            if (string.IsNullOrWhiteSpace(_person.Age.ToString()))
                error.AppendLine("Укажите возраст");
            if(error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            GokkeeEntities.GetGokkee().Person.Add(_person);
            try
            {
                GokkeeEntities.GetGokkee().SaveChanges();
                MessageBox.Show("Новый пользователь добавлен");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
